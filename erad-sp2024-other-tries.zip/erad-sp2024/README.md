# ERAD SP 2024

Desafio de programação da Escola Regional de Alto Desempenho SP 2024
