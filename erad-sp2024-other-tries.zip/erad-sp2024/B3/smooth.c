#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#include <mpi.h>
#include <omp.h>

#define image(x,y) pixels[y*width+x]
#define smooth(x,y) filtered[y*width+x]

typedef struct {
    char red, green, blue, alpha;
} RGBA;

int main(int argc, char *argv[]) {

    FILE *in;
    FILE *out;
    short width, height;
    int rank;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    in = fopen("image.in", "rb");
    if (in == NULL) {
        perror("image.in");
        exit(EXIT_FAILURE);
    }

    out = fopen("image.out", "wb");
    if (out == NULL) {
        perror("image.out");
        exit(EXIT_FAILURE);
    }

    fread(&width, sizeof (width), 1, in);
    fread(&height, sizeof (height), 1, in);

    fwrite(&width, sizeof (width), 1, out);
    fwrite(&height, sizeof (height), 1, out);

    RGBA *pixels = (RGBA *) malloc(height * width * sizeof (RGBA));
    RGBA *filtered = (RGBA *) malloc(height * width * sizeof (RGBA));
    RGBA *final_image = (RGBA *) malloc(height * width * sizeof (RGBA));
    memset(filtered, 0, height * width * sizeof(RGBA));

    if (pixels == NULL || filtered == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    int DY[] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, +0, +0, +0, +0, +0, +1, +1, +1, +1, +1, +2, +2, +2, +2, +2};
    int DX[] = {-2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2};
    int x, y, d, dx, dy, i;

    do {
        if (!fread(pixels, height * width * sizeof (RGBA), 1, in))
            break;

        for (y = 0;y < height; y++) {
            for (x = 0; x < width; x++) {
                long long int sum = 0;
                for (d = 0; d < 25; d++) {
                    dx = x + DX[d];
                    dy = y + DY[d];
                    if (dx >= 0 && dx < width && dy >= 0 && dy < height) {
                        sum += *(((char*) (&image(dx, dy))) + rank);
                    }
                }
                (*(((char*) (&smooth(x, y)) + rank))) = sum / 25;
            }
        }

        MPI_Reduce((char*)filtered, final_image, height * width * sizeof(RGBA), MPI_CHAR, MPI_SUM, 0, MPI_COMM_WORLD);
        fwrite(final_image, height * width * sizeof (RGBA), 1, out);

    } while (!feof(in));

    free(pixels);
    free(filtered);
    free(final_image);

    fclose(out);
    fclose(in);

    MPI_Finalize();

    return EXIT_SUCCESS;
}
