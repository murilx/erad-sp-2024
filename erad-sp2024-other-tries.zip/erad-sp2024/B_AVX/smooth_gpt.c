#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <omp.h>
#include <immintrin.h> // AVX header

#define image(x,y) pixels[y*width+x]
#define smooth(x,y) filtered[y*width+x]

typedef struct {
    char red, green, blue, alpha;
} RGBA;

int main(int argc, char *argv[]) {

    FILE *in;
    FILE *out;

    in = fopen("image.in", "rb");
    if (in == NULL) {
        perror("image.in");
        exit(EXIT_FAILURE);
    }

    out = fopen("image.out", "wb");
    if (out == NULL) {
        perror("image.out");
        exit(EXIT_FAILURE);
    }

    short width, height;

    fread(&width, sizeof(width), 1, in);
    fread(&height, sizeof(height), 1, in);

    fwrite(&width, sizeof(width), 1, out);
    fwrite(&height, sizeof(height), 1, out);

    RGBA *pixels = (RGBA *) malloc(height * width * sizeof(RGBA));
    RGBA *filtered = (RGBA *) malloc(height * width * sizeof(RGBA));

    if (pixels == NULL || filtered == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    int DY[] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, +0, +0, +0, +0, +0, +1, +1, +1, +1, +1, +2, +2, +2, +2, +2};
    int DX[] = {-2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2, -2, -1, +0, +1, +2};

    do {
        if (!fread(pixels, height * width * sizeof(RGBA), 1, in))
            break;

        for (y = 2; y < height - 2; y++) {
            for (x = 2; x < width - 2; x++) {
                __m256i sum_red = _mm256_setzero_si256();
                __m256i sum_green = _mm256_setzero_si256();
                __m256i sum_blue = _mm256_setzero_si256();
                __m256i sum_alpha = _mm256_setzero_si256();

                for (d = 0; d < 25; d++) {
                    dx = x + DX[d];
                    dy = y + DY[d];
                    RGBA *pixel = &image(dx, dy);

                    __m256i pixel_vals = _mm256_set_epi8(
                        0, 0, 0, 0,
                        0, 0, 0, 0,
                        pixel[7].alpha, pixel[7].blue, pixel[7].green, pixel[7].red,
                        pixel[6].alpha, pixel[6].blue, pixel[6].green, pixel[6].red,
                        pixel[5].alpha, pixel[5].blue, pixel[5].green, pixel[5].red,
                        pixel[4].alpha, pixel[4].blue, pixel[4].green, pixel[4].red,
                        pixel[3].alpha, pixel[3].blue, pixel[3].green, pixel[3].red,
                        pixel[2].alpha, pixel[2].blue, pixel[2].green, pixel[2].red,
                        pixel[1].alpha, pixel[1].blue, pixel[1].green, pixel[1].red,
                        pixel[0].alpha, pixel[0].blue, pixel[0].green, pixel[0].red
                    );

                    sum_red = _mm256_add_epi8(sum_red, _mm256_and_si256(pixel_vals, _mm256_set1_epi8(0xFF)));
                    sum_green = _mm256_add_epi8(sum_green, _mm256_and_si256(_mm256_srli_epi32(pixel_vals, 8), _mm256_set1_epi8(0xFF)));
                    sum_blue = _mm256_add_epi8(sum_blue, _mm256_and_si256(_mm256_srli_epi32(pixel_vals, 16), _mm256_set1_epi8(0xFF)));
                    sum_alpha = _mm256_add_epi8(sum_alpha, _mm256_and_si256(_mm256_srli_epi32(pixel_vals, 24), _mm256_set1_epi8(0xFF)));
                }

                sum_red = _mm256_div_epi8(sum_red, _mm256_set1_epi8(25));
                sum_green = _mm256_div_epi8(sum_green, _mm256_set1_epi8(25));
                sum_blue = _mm256_div_epi8(sum_blue, _mm256_set1_epi8(25));
                sum_alpha = _mm256_div_epi8(sum_alpha, _mm256_set1_epi8(25));

                RGBA result_pixel;
                result_pixel.red = _mm256_extract_epi8(sum_red, 0);
                result_pixel.green = _mm256_extract_epi8(sum_green, 0);
                result_pixel.blue = _mm256_extract_epi8(sum_blue, 0);
                result_pixel.alpha = _mm256_extract_epi8(sum_alpha, 0);

                smooth(x, y) = result_pixel;
            }
        }

        fwrite(filtered, height * width * sizeof(RGBA), 1, out);

    } while (!feof(in));

    free(pixels);
    free(filtered);

    fclose(out);
    fclose(in);

    return EXIT_SUCCESS;
}

