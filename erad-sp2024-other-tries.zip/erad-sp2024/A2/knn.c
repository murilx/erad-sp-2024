#include <mpi.h>
#include "knn.h"

char knn(int n_groups, Group * groups, int k, Point to_evaluate) {
    char * labels = (char *) malloc(sizeof(char) * k);
    float * distances = (float *) malloc(sizeof(float) * k);

    int i, j, x, y;
    int rank, comm_sz;

    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    Group *local_groups = (Group *) malloc(sizeof(Group) * n_groups / comm_sz);

    for (i = 0; i < k; i++) {
        labels[i] = -1;
        distances[i] = -1;
    }

    MPI_Scatterv(groups, sizeof(Group) * n_groups / comm_sz, MPI_BYTE,
        local_groups, sizeof(Group) * n_groups / comm_sz, MPI_BYTE, 0, MPI_COMM_WORLD);

    for (i = 0; i < n_groups / comm_sz; i++) {
        Group g = local_groups[i];

        for (j = 0; j < g.length; j++) {
            float d = euclidean_distance_no_sqrt(to_evaluate, g.points[j]);

            for (x = 0; x < k; x++) {
                if (d < distances[x] || distances[x] == -1) {
                    for (y = k - 1; y > x; y--) {
                        distances[y] = distances[y - 1];
                        labels[y] = labels[y - 1];
                    }

                    distances[x] = d;
                    labels[x] = g.label;

                    break;
                }
            }
        }
    }

    char *all_labels = (char *) malloc(sizeof(char) * k * comm_sz);
    float *all_distances = (float *) malloc(sizeof(float) * k * comm_sz);
    ArrayWrapper *data = (ArrayWrapper *) malloc(sizeof(ArrayWrapper) * k * comm_sz);

    MPI_Gather(labels, k, MPI_CHAR, all_labels, k, MPI_CHAR, 0, MPI_COMM_WORLD);
    MPI_Gather(distances, k, MPI_CHAR, all_distances, k, MPI_CHAR, 0, MPI_COMM_WORLD);

    for(i = 0; i < k * comm_sz; i++) {
        data[i].label = all_labels[i];
        data[i].distance = all_distances[i];
    }
    qsort(data, k * comm_sz, sizeof(ArrayWrapper), compare_struct);

    for(i = 0; i < k; i++)
        labels[i] = data[i].label;

    qsort(labels, k, sizeof(char), compare_for_sort);

    char most_frequent = labels[0];
    int most_frequent_count = 1;
    int current_frequency = 1;

    for (i = 1; i < k; i++) {
        if (labels[i] != labels[i - 1]) {
            if (current_frequency > most_frequent_count) {
                most_frequent = labels[i - 1];
                most_frequent_count = current_frequency;
            }

            current_frequency = 1;
        } else {
            current_frequency++;
        }

        if (i == k - 1 && current_frequency > most_frequent_count) {
            most_frequent = labels[i - 1];
            most_frequent_count = current_frequency;
        }
    }


    return most_frequent;
}

int main() {
    int rank;
    int n_groups, k;
    Group *groups;
    Point to_evaluate;
    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if(rank == 0) {
        n_groups = parse_number_of_groups();

        groups = (Group *) malloc(sizeof(Group) * n_groups);

        for (int i = 0; i < n_groups; i++) {
            groups[i] = parse_next_group();
        }

        k = parse_k();

        to_evaluate = parse_point();
    }

    char result = knn(n_groups, groups, k, to_evaluate);
    if(rank == 0)
        printf("%c", result);

    MPI_Finalize();
}
